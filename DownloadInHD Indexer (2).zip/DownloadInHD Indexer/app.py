# -*- coding: utf-8 -*-
import os, re, base64, json
from flask import Flask, render_template, request, redirect, url_for, abort, send_file

app = Flask(__name__)

# ========= CONFIG =========
ROOT_DIR = r"C:\Users\rocket\Videos"   # drill through this folder and all subfolders
FILE_EXTENSIONS = None                 # None = all files. Or set like [".mkv",".mp4",".avi"]
# =========================

def normalize(text: str) -> str:
    return re.sub(r'[\s._()-]+', '', text.lower())

def human_size(num: int) -> str:
    units = ["B","KB","MB","GB","TB"]
    size = float(num)
    for u in units:
        if size < 1024 or u == "TB":
            return f"{size:.2f} {u}"
        size /= 1024

def include_file(filename: str) -> bool:
    if FILE_EXTENSIONS is None:
        return True
    low = filename.lower()
    return any(low.endswith(ext) for ext in FILE_EXTENSIONS)

def walk_files(root: str):
    for d, _, files in os.walk(root):
        for name in files:
            if include_file(name):
                full = os.path.join(d, name)
                try:
                    st = os.stat(full)
                    yield full, name, st.st_size
                except Exception:
                    yield full, name, 0

def encode_path(p: str) -> str:
    return base64.urlsafe_b64encode(p.encode("utf-8")).decode("ascii")

def decode_path(token: str) -> str:
    try:
        return base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8")
    except Exception:
        return ""

def is_safe_path(base: str, target: str) -> bool:
    try:
        base = os.path.abspath(base)
        target = os.path.abspath(target)
        return os.path.commonpath([base]) == os.path.commonpath([base, target])
    except Exception:
        return False

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/search")
def search():
    q = request.args.get("q","").strip()
    sort = request.args.get("sort","size_desc")  # size_desc, size_asc
    files = []
    if q:
        nq = normalize(q)
        for full, name, size in walk_files(ROOT_DIR):
            if nq in normalize(name):
                files.append({
                    "name": name,
                    "size": size,
                    "size_h": human_size(size),
                    "id": encode_path(full)
                })
    if sort == "size_asc":
        files.sort(key=lambda x: x["size"])
    else:
        files.sort(key=lambda x: x["size"], reverse=True)
    return render_template("results.html", files=files, q=q, sort=sort, root=ROOT_DIR)

@app.route("/file/<fid>")
def file_details(fid):
    p = decode_path(fid)
    if not p or not is_safe_path(ROOT_DIR, p) or not os.path.isfile(p):
        abort(404)
    size = 0
    try:
        size = os.path.getsize(p)
    except Exception:
        pass
    return render_template("details.html", name=os.path.basename(p), size_h=human_size(size), fid=fid, path=p)

@app.route("/download/<fid>")
def download(fid):
    p = decode_path(fid)
    if not p or not is_safe_path(ROOT_DIR, p) or not os.path.isfile(p):
        abort(404)
    return send_file(p, as_attachment=True)

if __name__ == "__main__":
    if not os.path.isdir(ROOT_DIR):
        print("[Warning] ROOT_DIR does not exist:", ROOT_DIR)
    app.run(host="0.0.0.0", port=5000, debug=True)